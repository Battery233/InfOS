/*
 * include/assert.h
 * 
 * InfOS
 * Copyright (C) University of Edinburgh 2016.  All Rights Reserved.
 * 
 * Tom Spink <tspink@inf.ed.ac.uk>
 */
#ifndef ASSERT_H
#define	ASSERT_H

extern void __assertion_failure(const char *filename, int lineno, const char *expression) __attribute__((noreturn));
#define assert(_expr) do { if (!(_expr)) { __assertion_failure(__FILE__, __LINE__, #_expr); __builtin_unreachable(); } } while(0)

#define not_implemented() assert(false && "NOT IMPLEMENTED")

#endif	/* ASSERT_H */
