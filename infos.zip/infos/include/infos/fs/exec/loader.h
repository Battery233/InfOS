#ifndef LOADER_H
#define LOADER_H

#include <infos/util/string.h>

namespace infos
{
	namespace kernel
	{
		class Process;
	}
	
	namespace fs
	{
		namespace exec
		{
			class Loader
			{
			public:
				virtual ~Loader() { }
				virtual kernel::Process *load(const util::String& cmdline) = 0;
			};
		}
	}
}

#endif /* LOADER_H */

