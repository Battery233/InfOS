/*
 * include/mm/allocator.h
 * 
 * InfOS
 * Copyright (C) University of Edinburgh 2016.  All Rights Reserved.
 * 
 * Tom Spink <tspink@inf.ed.ac.uk>
 */
#ifndef ALLOCATOR_H
#define ALLOCATOR_H

#include <infos/define.h>

namespace infos
{
	namespace mm
	{
		class MemoryManager;
		
		class Allocator
		{
		public:
			Allocator(MemoryManager& mm) : _mm(mm) { }
			
			virtual bool init() = 0;
			
			MemoryManager& owner() const { return _mm; }
			
		private:
			MemoryManager& _mm;
		};
	}
}

#endif /* ALLOCATOR_H */

