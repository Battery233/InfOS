#ifndef RTTI_H
#define RTTI_H

namespace infos
{
	namespace util
	{
//		template<typename T>
//		class RTTI
//		{
//		private:
//			static uint64_t tag;
//			
//		public:
//			template<typename P>
//			RTTI(RTTI<P>& parent) { }
//		};
	}
}

#endif /* RTTI_H */

