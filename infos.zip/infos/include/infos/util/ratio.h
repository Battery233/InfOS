#ifndef RATIO_H
#define RATIO_H

#include <infos/define.h>

namespace infos {
	namespace util {

		template<typename _Tp, _Tp __v>
		struct IntegralConstant {
			static constexpr _Tp Value = __v;
			typedef _Tp value_type;
			typedef IntegralConstant<_Tp, __v> type;

			constexpr operator value_type() const {
				return Value;
			}

			constexpr value_type operator()() const {
				return Value;
			}
		};

		template<typename _Tp, _Tp __v>
		constexpr _Tp IntegralConstant<_Tp, __v>::Value;

		template<intmax_t _Pn>
		struct StaticSign : IntegralConstant<intmax_t, (_Pn < 0) ? -1 : 1 > {
		};

		template<intmax_t _Pn>
		struct StaticAbs : IntegralConstant<intmax_t, _Pn * StaticSign<_Pn>::Value> {
		};

		template<intmax_t _Pn, intmax_t _Qn>
		struct StaticGCD : StaticGCD<_Qn, (_Pn % _Qn)> {
		};

		template<intmax_t _Pn>
		struct StaticGCD<_Pn, 0> : IntegralConstant<intmax_t, StaticAbs<_Pn>::Value> {
		};

		template<intmax_t _Qn>
		struct StaticGCD<0, _Qn> : IntegralConstant<intmax_t, StaticAbs<_Qn>::Value> {
		};

		template<intmax_t _Pn, intmax_t _Qn>
		struct SafeMultiply {
		private:
			static const uintmax_t __c = uintmax_t(1) << (sizeof (intmax_t) * 4);

			static const uintmax_t __a0 = StaticAbs<_Pn>::Value % __c;
			static const uintmax_t __a1 = StaticAbs<_Pn>::Value / __c;
			static const uintmax_t __b0 = StaticAbs<_Qn>::Value % __c;
			static const uintmax_t __b1 = StaticAbs<_Qn>::Value / __c;

			static_assert(__a1 == 0 || __b1 == 0,
					"overflow in multiplication");
			static_assert(__a0 * __b1 + __b0 * __a1 < (__c >> 1),
					"overflow in multiplication");
			static_assert(__b0 * __a0 <= __INTMAX_MAX__,
					"overflow in multiplication");
			static_assert((__a0 * __b1 + __b0 * __a1) * __c
					<= __INTMAX_MAX__ - __b0 * __a0,
					"overflow in multiplication");

		public:
			static const intmax_t Value = _Pn * _Qn;
		};

		template<intmax_t _Num, intmax_t _Den = 1 >
		struct Ratio {
			static_assert(_Den != 0, "denominator cannot be zero");
			static_assert(_Num >= -__INTMAX_MAX__ && _Den >= -__INTMAX_MAX__, "out of range");

			// Note: sign(N) * abs(N) == N
			static constexpr intmax_t Num =
					_Num * StaticSign<_Den>::Value / StaticGCD<_Num, _Den>::Value;

			static constexpr intmax_t Den =
					StaticAbs<_Den>::Value / StaticGCD<_Num, _Den>::Value;

			typedef Ratio<Num, Den> type;
		};

		template<intmax_t _Num, intmax_t _Den>
		constexpr intmax_t Ratio<_Num, _Den>::Num;

		template<intmax_t _Num, intmax_t _Den>
		constexpr intmax_t Ratio<_Num, _Den>::Den;

		template<typename _R1, typename _R2>
		struct RatioMultiplyImpl {
		private:
			static const intmax_t __gcd1 =
					StaticGCD<_R1::Num, _R2::Den>::Value;
			static const intmax_t __gcd2 =
					StaticGCD<_R2::Num, _R1::Den>::Value;

		public:
			typedef Ratio<
			SafeMultiply<(_R1::Num / __gcd1), (_R2::Num / __gcd2)>::Value,
			SafeMultiply<(_R1::Den / __gcd2), (_R2::Den / __gcd1)>::Value> Type;

			static constexpr intmax_t Num = Type::Num;
			static constexpr intmax_t Den = Type::Den;
		};

		template<typename _R1, typename _R2>
		constexpr intmax_t RatioMultiplyImpl<_R1, _R2>::Num;

		template<typename _R1, typename _R2>
		constexpr intmax_t RatioMultiplyImpl<_R1, _R2>::Den;

		template<typename _R1, typename _R2>
		using RatioMultiply = typename RatioMultiplyImpl<_R1, _R2>::Type;

		template<typename _R1, typename _R2>
		struct RatioDivideImpl {
			static_assert(_R2::Num != 0, "division by 0");

			typedef typename RatioMultiplyImpl<_R1, Ratio<_R2::Den, _R2::Num> >::Type Type;

			static constexpr intmax_t Num = Type::Num;
			static constexpr intmax_t Den = Type::Den;
		};

		template<typename _R1, typename _R2>
		constexpr intmax_t RatioDivideImpl<_R1, _R2>::Num;

		template<typename _R1, typename _R2>
		constexpr intmax_t RatioDivideImpl<_R1, _R2>::Den;

		/// ratio_divide
		template<typename _R1, typename _R2>
		using RatioDivide = typename RatioDivideImpl<_R1, _R2>::Type;
	}
}

#endif /* RATIO_H */

