#ifndef OBJECT_H
#define OBJECT_H

#include <infos/define.h>

namespace infos
{
	namespace kernel
	{
		typedef uint64_t ObjectHandle;
		
		class KernelObject
		{
		public:
			ObjectHandle get_handle() const { return _handle; }
			
			static const ObjectHandle Error;
			
		private:
			ObjectHandle _handle;
		};
	}
}

#endif /* OBJECT_H */

