/*
 * include/kernel/thread-context.h
 * 
 * InfOS
 * Copyright (C) University of Edinburgh 2016.  All Rights Reserved.
 * 
 * Tom Spink <tspink@inf.ed.ac.uk>
 */
#ifndef THREAD_CONTEXT_H
#define THREAD_CONTEXT_H

// HACK HACK HACK
#include <arch/x86/context.h>

namespace infos
{
	namespace kernel
	{
		struct ThreadContext
		{
			X86Context *native_context;
			uintptr_t kernel_stack;
		} __packed;
	}
}

#endif /* THREAD_CONTEXT_H */
