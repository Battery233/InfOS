#ifndef QEMU_STREAM_H
#define QEMU_STREAM_H

#include <infos/io/stream.h>

namespace infos
{
	namespace arch
	{
		namespace x86
		{
			class QEMUStream : public io::Stream
			{
			public:
				int read(void* buffer, size_t size) override;
				int write(const void* buffer, size_t size) override;
			};
		}
	}
}

#endif /* QEMU_STREAM_H */

