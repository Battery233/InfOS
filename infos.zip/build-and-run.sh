#!/bin/sh

./build.sh && ./run.sh $*

